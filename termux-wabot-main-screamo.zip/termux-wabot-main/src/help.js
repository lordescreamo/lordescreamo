const help = (prefixo) => {
	return `> *Sticker Commandos by Lorde screamo* <
command : *${prefixo}sticker* or *${prefix}stiker*
desc : converter imagem/gif/video to sticker
usage : responder imagem / gif / vídeo ou enviar imagem / gif / vídeo com legenda \ n
command : *${prefix}sticker nobg* or *${prefix}stiker nobg*
desc : converter imagem em adesivo removendo o fundo
usage : responder imagem ou enviar imagem com legenda \ n
command : *${prefix}toimg*
desc : converter adesivo em imagem
usage : converter texto em adesivo
command : *${prefix}tsticker* or *${prefix}tstiker*
desc : converter texto em adesivo
usage : *${prefix}texto do adesivo aqui * \ n
> *Meme Commandos* <
command : *${prefix}meme*
desc : random meme images [english]
usage :basta enviar o comando \ n
command : *${prefix}memeindo*
desc : random meme images [indo]
usage : basta enviar o comando \ n
> *Outros Comandos* <
command : *${prefix}gtts*
desc :converter texto em fala / áudio
usage : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja On2-chan*\n
command : *${prefix}loli*
desc : random loli imagens
usage : basta enviar o comando \ n
command : *${prefix}nsfwloli*
desc : imagens aleatórias de nsfw loli
usage : basta enviar o comando \ n
command : *${prefix}url2img*
desc :tirar screenshots da web
usage : *${prefix}url2img [tipe] [url]*\n
command : *${prefix}simi*
desc : sua mensagem será respondida por simi
usage : *${prefix}simi sua mensagem * \ n
command : *${prefix}ocr*
desc : pegue o texto na foto
usage : responder imagem ou enviar imagemwith caption\n
command : *${prefix}espere*
desc : procure anime com imagem [ What Anime Is This/That ]
usage : responder imagem ou enviar imagem com legenda \ n
command : *${prefix}setprefix*
desc : replace prefix
usage : *${prefix}setprefix [text|optional]*\nexample : *${prefix}setprefix ?*
note : o comando só pode ser usado pelo proprietário do bot \ n
> *Grupo Comandos* <
command : *${prefix}add*
desc : adicionar membro ao grupo
usage : *${prefixo}adicionar 55813xxxxx*\n
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin! \ n
command : *${prefix}kick*
desc : remover membros do gp
usage : *${prefix}remover @tagmember*\n
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin! \ n
command : *${prefix}.promote*
desc : tornar o membro do grupo como administrador do grupo
usage : *${prefix}promote @tagmember*\n
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin! \ n
command : *${prefix}rl.remote*
desc : tornar o administrador do grupo como membro do grupo
usage : *${prefix}.remote @tagmember*\n
note :só pode ser usado quando o bot se torna admin, e quem envia o comando é admin! \ n
command : *${prefixo}.linkgroup*
desc : pegue o link do grupo
usage : apenas envie o comando
note : só pode ser usado quando o bot se torna admin, e quem envia o comando é admin! \ n
command : *${prefixo}.tagall*
desc : marca todos os membros do grupo, incluindo administradores também
usage : apenas envie o comando
note : Este comando pode ser usado se você for um administrador de grupo \ n
command : *${prefixo}simih*
desc : ative o modo simi no grupo
usage : *$ {prefix} simih 1 * para ativar o modo simi e * $ {prefix} simih 0 * para desativar o modo simi
note : Este comando pode ser usado se você for um administrador de grupo \ n`
}

exports.help = help
